import React from 'react';
import { View, Text } from 'react-native'

export default function GroupSearchScreen() {
 return (
  <View>
    <Text> GroupSearchScreen </Text>
  </View>
 ) 
}