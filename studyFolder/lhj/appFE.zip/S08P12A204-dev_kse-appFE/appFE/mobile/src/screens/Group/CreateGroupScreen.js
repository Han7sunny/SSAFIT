import React from 'react';
import { View, Text } from 'react-native'

export default function CreateGroupScreen() {
 return (
  <View>
    <Text> CreateGroupScreen </Text>
  </View>
 ) 
}