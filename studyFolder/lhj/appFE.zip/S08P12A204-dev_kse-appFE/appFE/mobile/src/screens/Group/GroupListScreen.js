import React from 'react';
import { View, Text } from 'react-native'

export default function GroupListScreen() {
 return (
  <View>
    <Text> GroupListScreen </Text>
  </View>
 ) 
}