import React from 'react'
import { StyleSheet,Text,View,ScrollView } from 'react-native'
// 자식 컴포넌트 import

const App = () => {
    return (
        <View>
            <Text>Containers</Text>
        </View>
    )
}