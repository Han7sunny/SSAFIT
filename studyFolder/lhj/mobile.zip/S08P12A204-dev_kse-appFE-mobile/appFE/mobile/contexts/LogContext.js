import { createContext } from 'react'

const LogContext = createContext('Hi')

export default LogContext