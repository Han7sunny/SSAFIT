import React from "react";
import { View, Text } from 'react-native'

export default function MyGroup() {
  return (
    <View>
      <Text> OOO님의 그룹 목록 </Text>
    </View>
  )
}