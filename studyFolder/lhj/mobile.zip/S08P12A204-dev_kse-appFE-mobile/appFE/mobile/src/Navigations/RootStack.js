// import React from 'react';
// import {createNativeStackNavigator} from '@react-navigation/native-stack';
// import MainTab from './MainTab';
// import CreateRoutineScreen from '../screens/Main/CreateRoutineScreen';

// const Stack = createNativeStackNavigator();

// export default function RootStack() {
//   return (
//     <Stack.Navigator>
//       <Stack.Screen
//         name="MainTab"
//         component={MainTab}
//         options={{headerShown: false}}
//       />
//       <Stack.Screen name="CreateRoutineScreen" component={CreateRoutineScreen} />
//     </Stack.Navigator>
//   );
// }